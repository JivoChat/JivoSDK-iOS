## Getting Started

You may find documentation here:
https://github.com/jivochat/jivosdk-ios
