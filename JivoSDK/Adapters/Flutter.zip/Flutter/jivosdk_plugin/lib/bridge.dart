import 'plugin.dart';

final class Jivo {
    static JVSession get session => JivoPlugin.instance.session;
    static JVDisplay get display => JivoPlugin.instance.display;
    static JVNotifications get notifications => JivoPlugin.instance.notifications;
    static JVDebugging get debugging => JivoPlugin.instance.debugging;
}

enum JVSessionServer {
    auto,
    asia,
    europe,
    russia
}

enum JVDisplayMenu {
    attach
}

enum JVNotificationsPermissionAskingMoment {
    never,
    onconnect,
    onappear,
    onsend
}

enum JVDebuggingLevel {
  silent,
  full
}
