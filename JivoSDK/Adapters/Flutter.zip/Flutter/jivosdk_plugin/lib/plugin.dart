import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:plugin_platform_interface/plugin_platform_interface.dart';
import 'bridge.dart';

class JVSubSystem {
    final MethodChannel channel;
    JVSubSystem(this.channel);

    void handleIncomingCall(MethodCall call) {
    }
}

class JVSession extends JVSubSystem {
    JVSession(MethodChannel channel): super(channel);

    Function _unreadCounterWatcher = (int number) {};

    Future<void> setPreferredServer(JVSessionServer server) async {
        await channel.invokeMethod<void>('session:setPreferredServer', {
            'server': server.toString().split('.').last
        });
    }

    Future<void> startUp({required String channelID, required String userToken}) async {
        await channel.invokeMethod<void>('session:startUp', {
            'channel_id': channelID,
            'user_token': userToken
        });
    }

    Future<void> setContactInfo({String? name, String? email, String? phone, String? brief}) async {
        await channel.invokeMethod<void>('session:setContactInfo', {
            'name': name ?? '',
            'email': email ?? '',
            'phone': phone ?? '',
            'brief': brief ?? ''
        });
    }

    Future<void> setCustomData(List<Map<String, String>> fields) async {
        await channel.invokeMethod<void>('session:setCustomData', fields);
    }

    Future<void> shutDown() async {
        await channel.invokeMethod<void>('session:shutDown');
    }

    void startWatchingUnreadCounter(Function watcher) {
        _unreadCounterWatcher = watcher;
    }

    @override
    void handleIncomingCall(MethodCall call) {
        switch (call.method) {
            case 'session:updateUnreadCounter(number)':
                final number = call.arguments as int;
                _unreadCounterWatcher(number);
        }
    }
}

class JVDisplay extends JVSubSystem {
    JVDisplay(MethodChannel channel): super(channel);

    Function _extraItemsCallback = (int index) {};
    Function _asksToAppearExecutor = () {};
    Function _willAppearExecutor = () {};
    Function _didAppearExecutor = () {};

    Future<bool> get isOnscreen async {
        final result = await channel.invokeMethod<bool>('display:isOnscreen').then<bool>((bool? value) => value ?? false);
        return result;
    }

    Future<void> setLocale(Locale locale) async {
        await channel.invokeMethod<void>('display:setLocale', locale.toString());
    }

    Future<void> setExtraItems({required JVDisplayMenu menu, required List<String> captions, required Function callback}) async {
        _extraItemsCallback = callback;
        await channel.invokeMethod<void>('display:setExtraItems', {
            'menu': menu.toString().split('.').last,
            'captions': captions
        });
    }

    Future<void> present() async {
        await channel.invokeMethod<void>('display:present');
    }

    void executeWhenAsksToAppear(Function executor) {
        _asksToAppearExecutor = executor;
    }

    void executeWhenWillAppear(Function executor) {
        _willAppearExecutor = executor;
    }

    void executeWhenDidDisappear(Function executor) {
        _didAppearExecutor = executor;
    }

    @override
    void handleIncomingCall(MethodCall call) {
        switch (call.method) {
            case 'display:setExtraItems:callback':
                final index = call.arguments as int;
                _extraItemsCallback(index);

            case 'display:asksToAppear':
                _asksToAppearExecutor();

            case 'display:willAppear':
                _willAppearExecutor();

            case 'display:didDisappear':
                _didAppearExecutor();
        }
    }
}

class JVNotifications extends JVSubSystem {
    JVNotifications(MethodChannel channel): super(channel);

    Future<void> setPermissionAsking(JVNotificationsPermissionAskingMoment moment) async {
        await channel.invokeMethod<void>('notifications:setPermissionAsking', {
            'moment': moment.toString().split('.').last
        });
    }

    @override
    void handleIncomingCall(MethodCall call) {
    }
}

class JVDebugging extends JVSubSystem {
    JVDebugging(MethodChannel channel): super(channel);

    Function _archiveLogsCallback = (String path) {};

    Future<void> setLevel(JVDebuggingLevel level) async {
        await channel.invokeMethod<void>('debugging:level', {
            'level': level.toString().split('.').last
        });
    }

    Future<void> archiveLogs({required Function completion}) async {
        _archiveLogsCallback = completion;
        await channel.invokeMethod<void>('debugging:archiveLogs');
    }

    @override
    void handleIncomingCall(MethodCall call) {
        switch (call.method) {
            case 'debugging:archiveLogs:callback':
                final url = call.arguments as String;
                _archiveLogsCallback(url);
        }
    }
}

final class JivoPlugin extends PlatformInterface {
    static final JivoPlugin instance = JivoPlugin._();
    static const _channel = MethodChannel('jivosdk_plugin');
    final JVSession session;
    final JVDisplay display;
    final JVNotifications notifications;
    final JVDebugging debugging;

    static final Object _token = Object();
    JivoPlugin._()
    : session = JVSession(_channel)
    , display = JVDisplay(_channel)
    , notifications = JVNotifications(_channel)
    , debugging = JVDebugging(_channel)
    , super(token: _token) {
        _channel.setMethodCallHandler((MethodCall call) async {
            session.handleIncomingCall(call);
            display.handleIncomingCall(call);
            notifications.handleIncomingCall(call);
            debugging.handleIncomingCall(call);
            return true;
        });
    }
}
